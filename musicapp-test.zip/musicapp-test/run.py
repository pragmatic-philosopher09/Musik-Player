from musicapp import app

